from app.models import ResearchSource
from app.services.research import source_sha256


class CaptureLlama:
    def __init__(self, response: str):
        self.response = response
        self.calls = []

    async def chat(self, messages, *, max_tokens, reasoning):
        self.calls.append(messages)
        return self.response


def test_chat_uses_source_as_untrusted_context_and_accepts_known_url(client, db_session, register_user):
    user_data, headers = register_user("chat-research@example.com")
    user_id = user_data["user_id"]
    content = "X1 stores source snapshots with a content hash."
    source = ResearchSource(
        user_id=user_id,
        project_id=None,
        url="https://example.com/article",
        final_url="https://example.com/article",
        title="Example",
        content=content,
        content_sha256=source_sha256(content),
        http_status=200,
        media_type="text/html",
        status="ready",
    )
    db_session.add(source)
    db_session.commit()
    fake = CaptureLlama("According to the source: https://example.com/article")
    client.app.state.llama = fake
    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "How are source snapshots stored?"}],
            "research_source_ids": [source.id],
        },
    )
    assert response.status_code == 200, response.text
    checks = {item["key"]: item for item in response.json()["quality"]["checks"]}
    assert checks["external_urls"]["status"] == "passed"
    first_call = fake.calls[0]
    source_messages = [m for m in first_call if "UNTRUSTED RESEARCH SOURCE EXCERPTS" in m.content]
    assert source_messages
    assert all(m.role == "user" for m in source_messages)


def test_chat_does_not_trust_invented_url(client, db_session, register_user):
    user_data, headers = register_user("chat-research-fake@example.com")
    user_id = user_data["user_id"]
    source = ResearchSource(
        user_id=user_id,
        url="https://example.com/article",
        final_url="https://example.com/article",
        title="Example",
        content="Relevant source text about X1.",
        content_sha256=source_sha256("Relevant source text about X1."),
        http_status=200,
        media_type="text/html",
        status="ready",
    )
    db_session.add(source)
    db_session.commit()
    fake = CaptureLlama("See https://invented.example/fake")
    client.app.state.llama = fake
    response = client.post(
        "/v1/chat",
        headers=headers,
        json={"messages": [{"role": "user", "content": "Tell me about X1"}], "research_source_ids": [source.id]},
    )
    assert response.status_code == 200
    assert response.json()["quality"]["status"] == "unverified"
