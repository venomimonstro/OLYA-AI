def test_register_login_me_logout(client, register_user):
    data, headers = register_user("User@Example.COM", display_name="User")

    me = client.get("/v1/auth/me", headers=headers)
    assert me.status_code == 200
    assert me.json()["email"] == "user@example.com"

    login = client.post("/v1/auth/login", json={"email": "user@example.com", "password": "very-secure-password"})
    assert login.status_code == 200
    second_headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    logout = client.post("/v1/auth/logout", headers=headers)
    assert logout.status_code == 204
    assert client.get("/v1/auth/me", headers=headers).status_code == 401
    assert client.get("/v1/auth/me", headers=second_headers).status_code == 200


def test_duplicate_email_is_rejected(client, register_user):
    register_user("dupe@example.com")
    response = client.post(
        "/v1/auth/register",
        json={"email": "DUPE@example.com", "password": "another-secure-password"},
    )
    assert response.status_code == 409
