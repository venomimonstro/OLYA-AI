
def test_account_export_contains_owned_and_created_data(client, register_user):
    _, headers = register_user("export@example.com")
    project = client.post("/v1/projects", headers=headers, json={"name": "Exportable", "instructions": "Keep this"}).json()
    response = client.get("/v1/account/export", headers=headers)
    assert response.status_code == 200
    payload = response.json()
    assert payload["account"]["email"] == "export@example.com"
    assert any(item["id"] == project["id"] for item in payload["owned_projects"])


def test_account_deactivate_revokes_current_session(client, register_user):
    _, headers = register_user("deactivate@example.com")
    response = client.post("/v1/account/deactivate", headers=headers)
    assert response.status_code == 204
    assert client.get("/v1/projects", headers=headers).status_code == 401
