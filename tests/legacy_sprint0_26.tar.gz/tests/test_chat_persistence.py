class FakeLlama:
    async def chat(self, messages, *, max_tokens, reasoning):
        return "verified fake response"


def test_chat_persists_messages_and_usage(client, register_user):
    _, headers = register_user("chat@example.com")
    client.app.state.llama = FakeLlama()

    response = client.post(
        "/v1/chat",
        headers=headers,
        json={"messages": [{"role": "user", "content": "hello"}], "mode": "fast"},
    )
    assert response.status_code == 200, response.text

    conversations = client.get("/v1/conversations", headers=headers).json()
    assert len(conversations) == 1
    messages = client.get(f"/v1/conversations/{conversations[0]['id']}/messages", headers=headers).json()
    assert [m["role"] for m in messages] == ["user", "assistant"]

    usage = client.get("/v1/usage/summary", headers=headers).json()
    assert usage["events"] == 1
    assert usage["output_chars"] == len("verified fake response")
