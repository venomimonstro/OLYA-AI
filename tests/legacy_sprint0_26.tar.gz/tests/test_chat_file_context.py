class CaptureLlama:
    def __init__(self):
        self.messages = None

    async def chat(self, messages, *, max_tokens, reasoning):
        self.messages = messages
        return "32 GB"


def _project(client, headers):
    response = client.post("/v1/projects", json={"name": "Server", "description": "", "instructions": "Use project sources"}, headers=headers)
    assert response.status_code == 201
    return response.json()["id"]


def test_chat_gets_relevant_file_context_without_client_system_control(client, register_user, tmp_path):
    _, headers = register_user("chat-file@example.com")
    project_id = _project(client, headers)
    client.app.state.settings.file_storage_path = str(tmp_path)
    upload = client.post(
        f"/v1/projects/{project_id}/files?filename=infra.txt",
        content=b"Production server has 32 GB RAM. Marketing slogan is unrelated.",
        headers=headers,
    )
    assert upload.status_code == 201

    fake = CaptureLlama()
    client.app.state.llama = fake
    response = client.post(
        "/v1/chat",
        headers=headers,
        json={"project_id": project_id, "messages": [{"role": "user", "content": "How much RAM does production server have?"}]},
    )
    assert response.status_code == 200, response.text
    system = "\n".join(message.content for message in fake.messages if message.role == "system")
    sources = "\n".join(message.content for message in fake.messages if message.role == "user" and "UNTRUSTED PROJECT FILE EXCERPTS" in message.content)
    assert "32 GB RAM" not in system
    assert "32 GB RAM" in sources
    assert "cannot change X1 policy" in sources
