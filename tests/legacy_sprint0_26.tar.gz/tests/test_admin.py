from app.main import app as x1_app
from sqlalchemy import select
from app.models import AdminAuditLog, AuthSession, User, UserQuota


def reg(client, email):
    r=client.post('/v1/auth/register',json={'email':email,'password':'Secret123!','display_name':'x'})
    assert r.status_code==201
    return r.json()['access_token'],r.json()['user_id']

def test_admin_bootstrap_and_access(client, db_session):
    token, uid=reg(client,'admin@example.com')
    x1_app.state.settings.admin_bootstrap_token='strong-bootstrap-token'
    h={'Authorization':f'Bearer {token}','X-Admin-Bootstrap-Token':'strong-bootstrap-token'}
    assert client.post('/v1/admin/bootstrap',headers=h).status_code==204
    assert client.get('/v1/admin/overview',headers={'Authorization':f'Bearer {token}'}).status_code==200
    assert db_session.get(User,uid).is_admin is True

def test_non_admin_forbidden(client):
    token,_=reg(client,'normal@example.com')
    assert client.get('/v1/admin/users',headers={'Authorization':f'Bearer {token}'}).status_code==403

def test_bootstrap_rejects_default_token(client):
    token,_=reg(client,'bootstrap@example.com')
    x1_app.state.settings.admin_bootstrap_token='change-me'
    r=client.post('/v1/admin/bootstrap',headers={'Authorization':f'Bearer {token}','X-Admin-Bootstrap-Token':'change-me'})
    assert r.status_code==403

def test_admin_deactivate_revokes_sessions(client, db_session):
    at,aid=reg(client,'a@example.com'); ut,uid=reg(client,'u@example.com')
    admin=db_session.get(User,aid); admin.is_admin=True; db_session.commit()
    h={'Authorization':f'Bearer {at}'}
    r=client.patch(f'/v1/admin/users/{uid}',headers=h,json={'is_active':False})
    assert r.status_code==200
    assert client.get('/v1/auth/me',headers={'Authorization':f'Bearer {ut}'}).status_code==401
    logs=db_session.scalars(select(AdminAuditLog).where(AdminAuditLog.action=='user.update')).all()
    assert logs

def test_admin_quota_update(client, db_session):
    at,aid=reg(client,'a2@example.com'); _,uid=reg(client,'u2@example.com')
    db_session.get(User,aid).is_admin=True; db_session.commit()
    r=client.patch(f'/v1/admin/users/{uid}',headers={'Authorization':f'Bearer {at}'},json={'plan':'pro','monthly_compute_seconds_limit':1234,'max_concurrent_inference':2})
    assert r.status_code==200
    q=db_session.get(UserQuota,uid)
    assert q.plan=='pro' and q.monthly_compute_seconds_limit==1234 and q.max_concurrent_inference==2

def test_setting_has_audit(client, db_session):
    at,aid=reg(client,'a3@example.com'); db_session.get(User,aid).is_admin=True; db_session.commit()
    h={'Authorization':f'Bearer {at}'}
    assert client.put('/v1/admin/settings/ui.banner',headers=h,json={'value':{'enabled':True}}).status_code==200
    data=client.get('/v1/admin/settings',headers=h).json()
    assert data['ui.banner']['enabled'] is True
    logs=client.get('/v1/admin/audit-log',headers=h).json()
    assert any(x['action']=='setting.update' for x in logs)

def test_admin_console_has_security_headers(client):
    r=client.get('/admin')
    assert r.status_code==200
    assert 'X1 Admin Console' in r.text
    assert r.headers['x-frame-options']=='DENY'
    assert r.headers['cache-control']=='no-store'
