import io
import zipfile
from pathlib import Path


def _zip(entries: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, content in entries.items():
            zf.writestr(name, content)
    return buf.getvalue()


def test_workspace_create_write_map_and_preimage(client, register_user, tmp_path, monkeypatch):
    _, headers = register_user("coder@example.com")
    monkeypatch.setattr(client.app.state.settings, "code_workspace_storage_path", str(tmp_path / "ws"))
    created = client.post("/v1/code/workspaces", json={"name": "repo"}, headers=headers)
    assert created.status_code == 201, created.text
    ws = created.json()
    write = client.put(f"/v1/code/workspaces/{ws['id']}/file", json={"path": "app/main.py", "content": "print('a')\n"}, headers=headers)
    assert write.status_code == 200, write.text
    old = write.json()["after_sha256"]
    conflict = client.put(f"/v1/code/workspaces/{ws['id']}/file", json={"path": "app/main.py", "content": "print('b')\n", "expected_sha256": "0" * 64}, headers=headers)
    assert conflict.status_code == 409
    good = client.put(f"/v1/code/workspaces/{ws['id']}/file", json={"path": "app/main.py", "content": "print('b')\n", "expected_sha256": old}, headers=headers)
    assert good.status_code == 200
    mapping = client.get(f"/v1/code/workspaces/{ws['id']}/map", headers=headers).json()
    assert mapping["file_count"] == 1
    assert mapping["files"][0]["path"] == "app/main.py"


def test_workspace_zip_rejects_traversal(client, register_user, tmp_path, monkeypatch):
    _, headers = register_user("zip@example.com")
    monkeypatch.setattr(client.app.state.settings, "code_workspace_storage_path", str(tmp_path / "ws"))
    ws = client.post("/v1/code/workspaces", json={"name": "repo"}, headers=headers).json()
    bad = client.post(f"/v1/code/workspaces/{ws['id']}/import-zip", content=_zip({"../escape.py": "x"}), headers={**headers, "Content-Type": "application/zip"})
    assert bad.status_code == 422
    assert not (tmp_path / "escape.py").exists()


def test_agent_scope_command_budget_and_completion(client, register_user, tmp_path, monkeypatch):
    _, headers = register_user("agent@example.com")
    monkeypatch.setattr(client.app.state.settings, "code_workspace_storage_path", str(tmp_path / "ws"))
    ws = client.post("/v1/code/workspaces", json={"name": "repo"}, headers=headers).json()
    client.put(f"/v1/code/workspaces/{ws['id']}/file", json={"path": "src/a.py", "content": "VALUE=1\n"}, headers=headers)
    run = client.post(f"/v1/code/workspaces/{ws['id']}/agent-runs", json={"goal": "change value", "allowed_paths": ["src"], "max_commands": 1}, headers=headers)
    assert run.status_code == 201, run.text
    rid = run.json()["id"]
    denied = client.put(f"/v1/code/agent-runs/{rid}/file", json={"path": "README.md", "content": "no"}, headers=headers)
    assert denied.status_code == 403
    good = client.put(f"/v1/code/agent-runs/{rid}/file", json={"path": "src/a.py", "content": "VALUE=2\n"}, headers=headers)
    assert good.status_code == 200
    cmd = client.post(f"/v1/code/agent-runs/{rid}/command", json={"argv": ["python", "-m", "py_compile", "src/a.py"], "timeout_seconds": 10}, headers=headers)
    assert cmd.status_code == 200, cmd.text
    assert cmd.json()["command_results"][-1]["exit_code"] == 0
    exhausted = client.post(f"/v1/code/agent-runs/{rid}/command", json={"argv": ["python", "--version"]}, headers=headers)
    assert exhausted.status_code == 409
    done = client.post(f"/v1/code/agent-runs/{rid}/complete", headers=headers)
    assert done.status_code == 200
    assert done.json()["status"] == "completed"


def test_agent_rejects_shell_and_preserves_checkpoint(client, register_user, tmp_path, monkeypatch):
    _, headers = register_user("safe-agent@example.com")
    monkeypatch.setattr(client.app.state.settings, "code_workspace_storage_path", str(tmp_path / "ws"))
    ws = client.post("/v1/code/workspaces", json={"name": "repo"}, headers=headers).json()
    rid = client.post(f"/v1/code/workspaces/{ws['id']}/agent-runs", json={"goal": "safe edit"}, headers=headers).json()["id"]
    plan = client.patch(f"/v1/code/agent-runs/{rid}/plan", json={"plan": [{"step": "inspect"}], "checkpoint": {"phase": "inspect", "cursor": 1}}, headers=headers)
    assert plan.status_code == 200
    denied = client.post(f"/v1/code/agent-runs/{rid}/command", json={"argv": ["bash", "-c", "echo bad"]}, headers=headers)
    assert denied.status_code == 403
    fetched = client.get(f"/v1/code/agent-runs/{rid}", headers=headers).json()
    assert fetched["checkpoint"]["cursor"] == 1
