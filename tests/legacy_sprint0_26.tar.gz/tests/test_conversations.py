def test_personal_conversation_is_private(client, register_user):
    u1, h1 = register_user("one@example.com")
    u2, h2 = register_user("two@example.com")

    conv = client.post("/v1/conversations", headers=h1, json={"title": "private"})
    assert conv.status_code == 201
    conv_id = conv.json()["id"]

    assert client.get(f"/v1/conversations/{conv_id}/messages", headers=h2).status_code == 404
