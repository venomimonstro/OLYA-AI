from scripts.benchmark_host import cpu_info, mem_info


def test_cpu_info_has_required_fields():
    data = cpu_info()
    assert "logical_cpus" in data
    assert "avx2" in data


def test_mem_info_is_nonnegative():
    data = mem_info()
    assert data["mem_total_gb"] >= 0
    assert data["mem_available_gb"] >= 0
