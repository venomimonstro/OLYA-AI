from app.schemas.chat import ChatMessage
from app.services.context import ContextCompiler


def test_context_deduplicates_exact_repeats():
    messages = [
        ChatMessage(role="system", content="rules"),
        ChatMessage(role="user", content="hello"),
        ChatMessage(role="assistant", content="answer"),
        ChatMessage(role="user", content="hello"),
    ]
    compiled = ContextCompiler().compile(messages)
    assert sum(1 for m in compiled if m.content == "hello") == 1
    assert compiled[0].role == "system"


def test_context_keeps_latest_turns_under_budget():
    messages = [ChatMessage(role="user", content=str(i) * 100) for i in range(10)]
    compiled = ContextCompiler(max_chars=250).compile(messages)
    assert compiled[-1].content == "9" * 100
    assert sum(len(m.content) for m in compiled) <= 300
