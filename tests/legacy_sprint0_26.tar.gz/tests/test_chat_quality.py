class SequenceLlama:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def chat(self, messages, *, max_tokens, reasoning):
        self.calls.append(messages)
        return self.responses.pop(0)


def test_auto_repairs_failed_formal_requirement(client, register_user):
    _, headers = register_user("quality-repair@example.com")
    fake = SequenceLlama(["Draft TODO", "Final contains READY"])
    client.app.state.llama = fake

    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "Give the final answer"}],
            "requirements": [{"kind": "contains", "value": "READY"}],
        },
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["text"] == "Final contains READY"
    assert data["quality"]["status"] == "checked"
    assert len(fake.calls) == 2


def test_strict_critic_can_fail_but_not_self_verify(client, register_user):
    _, headers = register_user("quality-strict@example.com")
    fake = SequenceLlama([
        "The result is 42.",
        '{"issues":[{"severity":"major","message":"The requested explanation is missing"}],"summary":"incomplete"}',
    ])
    client.app.state.llama = fake

    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "Explain the result"}],
            "verification": "strict",
        },
    )
    assert response.status_code == 200, response.text
    assert response.json()["quality"]["status"] == "failed"
    assert len(fake.calls) == 2


def test_strict_critic_cannot_verify_unchecked_url(client, register_user):
    _, headers = register_user("quality-url@example.com")
    fake = SequenceLlama([
        "See https://example.com/reference",
        '{"issues":[],"summary":"No obvious contradiction"}',
    ])
    client.app.state.llama = fake

    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "Give a source"}],
            "verification": "strict",
        },
    )
    assert response.status_code == 200
    assert response.json()["quality"]["status"] == "unverified"


def test_verification_off_does_not_run_quality_or_repair(client, register_user):
    _, headers = register_user("quality-off@example.com")
    fake = SequenceLlama(["TODO unfinished"])
    client.app.state.llama = fake
    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "Draft"}],
            "verification": "off",
        },
    )
    assert response.status_code == 200
    assert response.json()["quality"] is None
    assert len(fake.calls) == 1


def test_quality_audit_is_private_and_retrievable(client, register_user):
    _, owner_headers = register_user("quality-owner@example.com")
    _, other_headers = register_user("quality-other@example.com")
    client.app.state.llama = SequenceLlama(["clean answer"])
    response = client.post(
        "/v1/chat",
        headers=owner_headers,
        json={"messages": [{"role": "user", "content": "Hello"}]},
    )
    audit_id = response.json()["quality"]["audit_id"]
    own = client.get(f"/v1/quality/audits/{audit_id}", headers=owner_headers)
    assert own.status_code == 200
    hidden = client.get(f"/v1/quality/audits/{audit_id}", headers=other_headers)
    assert hidden.status_code == 404


def test_requirements_stay_user_level_not_system(client, register_user):
    _, headers = register_user("quality-role@example.com")
    fake = SequenceLlama(["MUST"])
    client.app.state.llama = fake
    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "Answer"}],
            "requirements": [{"kind": "contains", "value": "MUST"}],
        },
    )
    assert response.status_code == 200
    first_call = fake.calls[0]
    requirement_messages = [m for m in first_call if "USER OUTPUT REQUIREMENTS" in m.content]
    assert requirement_messages
    assert all(m.role == "user" for m in requirement_messages)

class PrimaryThenUnavailable:
    def __init__(self, primary):
        self.primary = primary
        self.calls = 0

    async def chat(self, messages, *, max_tokens, reasoning):
        from app.inference.client import LlamaUnavailable
        self.calls += 1
        if self.calls == 1:
            return self.primary
        raise LlamaUnavailable("secondary unavailable")


def test_secondary_critic_failure_preserves_primary_answer(client, register_user):
    _, headers = register_user("quality-degrade@example.com")
    fake = PrimaryThenUnavailable("Primary answer")
    client.app.state.llama = fake
    response = client.post(
        "/v1/chat",
        headers=headers,
        json={
            "messages": [{"role": "user", "content": "Check carefully"}],
            "verification": "strict",
        },
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["text"] == "Primary answer"
    assert data["quality"]["status"] == "unverified"
    assert any("недоступна" in item for item in data["quality"]["warnings"])
