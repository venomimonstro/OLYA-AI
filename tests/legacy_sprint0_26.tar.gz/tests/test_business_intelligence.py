from app.services.business_intelligence import build_business_candidates, normalize_business_name, recommendation_summary


def test_normalize_business_name_removes_generic_words():
    assert normalize_business_name("Стоматология Дента — официальный сайт") == "дента"


def test_business_candidates_group_same_catalog_title():
    rows = [
        {"title":"Дента — отзывы", "url":"https://yandex.ru/maps/org/denta", "source_kind":"maps_catalog", "provider":"brave"},
        {"title":"Дента отзывы пациентов", "url":"https://prodoctorov.ru/samara/lpu/denta", "source_kind":"reviews", "provider":"brave"},
    ]
    candidates = build_business_candidates(rows)
    assert len(candidates) == 1
    assert candidates[0].independent_source_count >= 2


def test_business_score_is_evidence_not_quality_and_no_fake_winner():
    rows = [
        {"title":"Дента официальный сайт", "url":"https://denta.example", "source_kind":"official_candidate", "provider":"brave"},
        {"title":"Смайл официальный сайт", "url":"https://smile.example", "source_kind":"official_candidate", "provider":"brave"},
    ]
    candidates = build_business_candidates(rows)
    summary = recommendation_summary(candidates)
    assert summary["decisive_winner"] is False
    assert "Недостаточно" in summary["message"]


def test_conflicting_identity_reduces_evidence_score():
    rows = [
        {"title":"Альфа стоматология", "url":"https://catalog.example/a", "source_kind":"maps_catalog", "provider":"brave"},
        {"title":"Бета клиника", "url":"https://reviews.example/a", "source_kind":"reviews", "provider":"brave"},
        {"title":"Гамма центр", "url":"https://other.example/a", "source_kind":"web", "provider":"brave"},
    ]
    candidates = build_business_candidates(rows)
    assert len(candidates) == 3

from app.services.business_intelligence import extract_public_rating


def test_public_rating_only_from_independent_catalog_or_review_source():
    assert extract_public_rating({"source_kind":"official_candidate", "title":"Рейтинг 5.0 999 отзывов"}) == (None, None)
    rating, reviews = extract_public_rating({"source_kind":"reviews", "title":"Дента 4,8 120 отзывов"})
    assert rating == 4.8
    assert reviews == 120


def test_two_independent_ratings_make_candidate_comparable():
    rows = [
        {"title":"Дента отзывы 4.8 120 отзывов", "snippet":"", "url":"https://yandex.ru/maps/org/denta", "source_kind":"maps_catalog", "provider":"brave"},
        {"title":"Дента отзывы 4.7 80 отзывов", "snippet":"", "url":"https://prodoctorov.ru/denta", "source_kind":"reviews", "provider":"other"},
    ]
    candidate = build_business_candidates(rows)[0]
    assert candidate.rating_source_count == 2
    assert candidate.review_count_total == 200
    assert candidate.comparison_state == "comparable"
    assert candidate.comparison_score is not None
